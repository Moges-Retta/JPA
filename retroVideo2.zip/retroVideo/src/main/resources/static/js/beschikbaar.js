var beschikbaar = document.getElementById("beschikbaar").innerText;
if(beschikbaar=="0"){
document.getElementsByTagName(("button").disabled=true;
}

document.querySelector("form").onsubmit = function() {
this.querySelector("button").disabled = true;
}
