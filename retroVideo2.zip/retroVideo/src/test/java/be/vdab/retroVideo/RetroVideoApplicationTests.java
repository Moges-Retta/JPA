package be.vdab.retroVideo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetroVideoApplicationTests {

	@Test
	void contextLoads() {
	}

}
