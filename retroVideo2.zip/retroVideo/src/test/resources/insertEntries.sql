insert into klanten(familienaam,voornaam,straatnummer,postcode,gemeente) values('test', 'test', "1","0","0");
